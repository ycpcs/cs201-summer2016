package edu.ycp.cs201.coins;

public class Coins {
	// TODO: add fields here

	// TODO: add constructors
	
	// TODO: add methods
}
