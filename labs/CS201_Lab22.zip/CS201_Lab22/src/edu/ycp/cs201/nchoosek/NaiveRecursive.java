package edu.ycp.cs201.nchoosek;

public class NaiveRecursive implements ComputeBinomialCoefficient {
	public int compute(int n, int k) {
		// TODO: implement
		throw new UnsupportedOperationException("not implemented yet!");
	}
	
	public String toString() {
		return "Naive Recursive";
	}
}
