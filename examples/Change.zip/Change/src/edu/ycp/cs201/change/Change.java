package edu.ycp.cs201.change;

import java.util.ArrayList;
import java.util.List;

public class Change {
	private List<Integer> coins;
	
	public Change() {
		coins = new ArrayList<Integer>();
	}
	
	public void add(int coin) {
		coins.add(coin);
	}
	
	public int size() {
		return coins.size();
	}

	public void addAll(Change sub) {
		coins.addAll(sub.coins);
	}
	
	@Override
	public String toString() {
		return coins.toString();
	}
}
