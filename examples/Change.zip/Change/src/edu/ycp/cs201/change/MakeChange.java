package edu.ycp.cs201.change;

import java.util.Scanner;

public class MakeChange {
	private static int[] DENOM = {
			1, 5, 10, 21, 25,
	};
	
	public static void main(String[] args) {
		Scanner keyboard = new Scanner(System.in);
		
		System.out.print("How many cents? ");
		int cents = keyboard.nextInt();
		
		Change[] memo = new Change[cents + 1];
		
		for (int coin : DENOM) {
			memo[coin] = new Change();
			memo[coin].add(coin);
		}
		
		for (int i = 1; i <= cents; i++) {
			if (memo[i] == null) {
				// Try adding one coin to previous
				// optimal solutions
				Change candidate = null;
				for (int coin : DENOM) {
					int remain = i - coin;
					if (remain > 0) {
						Change sub = memo[remain];
						Change c = new Change();
						c.addAll(sub);
						c.add(coin);
						if (candidate == null ||
								c.size() < candidate.size()) {
							candidate = c;
						}
					}
				}
				memo[i] = candidate;
			}
		}
		System.out.println("Optimal solution: " + memo[cents]);
	}
}
