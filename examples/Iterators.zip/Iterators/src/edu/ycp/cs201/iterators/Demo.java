package edu.ycp.cs201.iterators;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

public class Demo {
	private ArrayList<Integer> l;
	private LinkedList<Integer> l2;
	private HashSet<Integer> hs;
	
	@Before
	public void setUp() {
		l = new ArrayList<Integer>();
		l.add(1);
		l.add(2);
		l.add(3);
		
		l2 = new LinkedList<Integer>();
		l2.add(4);
		l2.add(5);
		l2.add(100);
		
		hs = new HashSet<Integer>();
		hs.add(7);
		hs.add(3);
		hs.add(11);
	}
	
	@Test
	public void testSumAll() {
		assertEquals(6, sumAll(l));
		assertEquals(109, sumAll(l2));
		assertEquals(21, sumAll(hs));
	}
	
	public static int sumAll(Collection<Integer> coll) {
		int sum = 0;
		
		// Doesn't work: not all collections use indices
//		for (int i = 0; i < coll.size(); i++) {
//			sum += coll.get(i);
//		}
		
		// Always works: use an Iterator
//		Iterator<Integer> i = coll.iterator();
//		while (i.hasNext()) {
//			Integer val = i.next();
//			sum += val;
//		}
		
		// Always works: for each loop
		for (Integer val : coll) {
			sum += val;
		}
		
		return sum;
	}
}
